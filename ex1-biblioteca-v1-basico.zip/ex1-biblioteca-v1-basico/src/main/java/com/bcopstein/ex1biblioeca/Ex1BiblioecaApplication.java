package com.bcopstein.ex1biblioeca;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Ex1BiblioecaApplication {

	public static void main(String[] args) {
		SpringApplication.run(Ex1BiblioecaApplication.class, args);
	}

}

