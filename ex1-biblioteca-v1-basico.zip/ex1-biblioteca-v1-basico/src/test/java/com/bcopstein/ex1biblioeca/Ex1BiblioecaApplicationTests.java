package com.bcopstein.ex1biblioeca;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Ex1BiblioecaApplicationTests {

	@Test
	void contextLoads() {
	}

}
